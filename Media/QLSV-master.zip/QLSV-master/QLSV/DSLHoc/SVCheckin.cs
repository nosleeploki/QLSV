﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV.DSLHoc
{
    public partial class SVCheckin : Form
    {
        public SVCheckin()
        {
            InitializeComponent();
        }

        private void SVCheckin_Load(object sender, EventArgs e)
        {

        }
    }
}
